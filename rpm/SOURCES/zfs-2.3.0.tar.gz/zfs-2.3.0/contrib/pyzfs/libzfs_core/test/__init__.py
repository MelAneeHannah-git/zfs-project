# `make distclean` deletes files with size 0. This comment is to avoid that.
